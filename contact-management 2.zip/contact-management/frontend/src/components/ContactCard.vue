<template>
  <div class="card bg-base-100 shadow p-4 mb-4 flex flex-col md:flex-row md:items-center md:justify-between">
    <div>
      <div class="font-bold text-lg">{{ contact.name }}</div>
      <div class="text-sm text-base-content/70">{{ contact.email }}</div>
      <div class="text-sm text-base-content/70">{{ contact.phone }}</div>
    </div>
    <div class="mt-2 md:mt-0 flex gap-2">
      <button class="btn btn-sm btn-primary" @click="$emit('edit', contact)">Edit</button>
      <button class="btn btn-sm btn-error" @click="$emit('delete', contact._id)">Delete</button>
      <router-link :to="`/contacts/${contact._id}`" class="btn btn-sm btn-outline">Details</router-link>
    </div>
  </div>
</template>

<script setup>
defineProps({
  contact: Object
});
</script>
