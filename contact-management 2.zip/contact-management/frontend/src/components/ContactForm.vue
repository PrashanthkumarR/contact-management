<template>
  <form @submit.prevent="$emit('submit', form)" class="space-y-4">
    <input v-model="form.name" class="input input-bordered w-full" placeholder="Name" required />
    <input v-model="form.email" class="input input-bordered w-full" placeholder="Email" type="email" required />
    <input v-model="form.phone" class="input input-bordered w-full" placeholder="Phone" required />
    <div class="flex gap-2">
      <button class="btn btn-primary" type="submit">{{ submitLabel }}</button>
      <button v-if="showCancel" class="btn btn-ghost" type="button" @click="$emit('cancel')">Cancel</button>
    </div>
  </form>
</template>

<script setup>
import { reactive, watch, toRefs } from 'vue';
const props = defineProps({
  contact: Object,
  submitLabel: { type: String, default: 'Save' },
  showCancel: { type: Boolean, default: false }
});
const form = reactive({
  name: props.contact?.name || '',
  email: props.contact?.email || '',
  phone: props.contact?.phone || ''
});
watch(() => props.contact, (val) => {
  form.name = val?.name || '';
  form.email = val?.email || '';
  form.phone = val?.phone || '';
});
</script>
