<template>
  <div class="flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md p-8 bg-base-100 rounded shadow">
      <h2 class="text-2xl font-bold mb-6">Login</h2>
      <form @submit.prevent="login">
        <div class="mb-4">
          <input v-model="username" class="input input-bordered w-full" placeholder="Username" required />
        </div>
        <div class="mb-4">
          <input v-model="password" type="password" class="input input-bordered w-full" placeholder="Password" required />
        </div>
        <button class="btn btn-primary w-full" :disabled="loading">Login</button>
        <div v-if="error" class="text-error mt-2">{{ error }}</div>
      </form>
      <div class="mt-4 text-center">
        <router-link to="/register" class="link">Don't have an account? Register</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../store/auth';

const router = useRouter();
const auth = useAuthStore();
const username = ref('');
const password = ref('');

const login = async () => {
  await auth.login(username.value, password.value);
  if (!auth.error) router.push('/');
};
const loading = computed(() => auth.loading);
const error = computed(() => auth.error);
</script>
