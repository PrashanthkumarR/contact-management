<template>
  <div class="container mx-auto py-8">
    <router-link to="/" class="btn btn-ghost mb-4">Back to Contacts</router-link>
    <div v-if="contact" class="card bg-base-100 shadow mb-6">
      <div class="card-body">
        <h2 class="card-title">{{ contact.name }}</h2>
        <p>{{ contact.email }}</p>
        <p>{{ contact.phone }}</p>
      </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div>
        <h3 class="text-xl font-bold mb-2">Notes</h3>
        <form class="mb-4" @submit.prevent="addNote">
          <input v-model="noteContent" class="input input-bordered w-full mb-2" placeholder="Add note..." required />
          <button class="btn btn-primary w-full">Add Note</button>
        </form>
        <ul>
          <li v-for="note in notesStore.notes" :key="note._id" class="mb-2 flex justify-between items-center">
            <span>{{ note.content }}</span>
            <button class="btn btn-xs btn-error" @click="deleteNote(note._id)">Delete</button>
          </li>
        </ul>
      </div>
      <div>
        <h3 class="text-xl font-bold mb-2">Action Logs</h3>
        <form class="mb-4" @submit.prevent="addAction">
          <select v-model="actionType" class="select select-bordered w-full mb-2" required>
            <option disabled value="">Means of Contact</option>
            <option value="email">Email</option>
            <option value="call">Call</option>
            <option value="in-person">In Person</option>
          </select>
          <input v-model="actionDate" type="date" class="input input-bordered w-full mb-2" required />
          <input v-model="actionNotes" class="input input-bordered w-full mb-2" placeholder="Notes (optional)" />
          <button class="btn btn-primary w-full">Add Action</button>
        </form>
        <ul>
          <li v-for="action in actionsStore.actions" :key="action._id" class="mb-2 flex justify-between items-center">
            <span>{{ action.actionType }} on {{ action.date?.slice(0,10) }} - {{ action.notes }}</span>
            <button class="btn btn-xs btn-error" @click="deleteAction(action._id)">Delete</button>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute } from 'vue-router';
import { useContactsStore } from '../store/contacts';
import { useNotesStore } from '../store/notes';
import { useActionsStore } from '../store/actions';

const route = useRoute();
const contactsStore = useContactsStore();
const notesStore = useNotesStore();
const actionsStore = useActionsStore();

const contactId = computed(() => route.params.id);
const contact = computed(() => contactsStore.contacts.find(c => c._id === contactId.value));

const noteContent = ref('');
const actionType = ref('');
const actionDate = ref('');
const actionNotes = ref('');

onMounted(() => {
  contactsStore.fetchContacts();
  notesStore.fetchNotes(contactId.value);
  actionsStore.fetchActions(contactId.value);
});

const addNote = async () => {
  await notesStore.addNote(contactId.value, noteContent.value);
  noteContent.value = '';
};
const deleteNote = async (noteId) => {
  await notesStore.deleteNote(contactId.value, noteId);
};

const addAction = async () => {
  await actionsStore.addAction(contactId.value, {
    actionType: actionType.value,
    date: actionDate.value,
    notes: actionNotes.value,
  });
  actionType.value = '';
  actionDate.value = '';
  actionNotes.value = '';
};
const deleteAction = async (actionId) => {
  await actionsStore.deleteAction(contactId.value, actionId);
};
</script>
