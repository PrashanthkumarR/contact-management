<template>
  <div class="container mx-auto py-8">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-3xl font-bold">Contacts</h1>
      <button class="btn btn-primary" @click="showAdd = true">Add Contact</button>
    </div>
    <div v-if="contactsStore.loading" class="text-center">Loading...</div>
    <div v-else>
      <div v-if="contactsStore.contacts.length === 0" class="text-center">No contacts found.</div>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div v-for="contact in contactsStore.contacts" :key="contact._id" class="card bg-base-100 shadow">
          <div class="card-body">
            <h2 class="card-title">{{ contact.name }}</h2>
            <p>{{ contact.email }}</p>
            <p>{{ contact.phone }}</p>
            <router-link :to="`/contacts/${contact._id}`" class="btn btn-sm btn-outline mt-2">View Details</router-link>
            <button class="btn btn-sm btn-error mt-2" @click="deleteContact(contact._id)">Delete</button>
          </div>
        </div>
      </div>
    </div>
    <dialog v-if="showAdd" class="modal modal-open">
      <form class="modal-box" @submit.prevent="addContact">
        <h3 class="font-bold text-lg mb-4">Add Contact</h3>
        <input v-model="name" class="input input-bordered w-full mb-2" placeholder="Name" required />
        <input v-model="email" class="input input-bordered w-full mb-2" placeholder="Email" required />
        <input v-model="phone" class="input input-bordered w-full mb-2" placeholder="Phone" required />
        <div class="modal-action">
          <button class="btn" type="button" @click="showAdd = false">Cancel</button>
          <button class="btn btn-primary" type="submit">Add</button>
        </div>
      </form>
    </dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useContactsStore } from '../store/contacts';
import { useAuthStore } from '../store/auth';
import { useRouter } from 'vue-router';

const contactsStore = useContactsStore();
const authStore = useAuthStore();
const router = useRouter();
const showAdd = ref(false);
const name = ref('');
const email = ref('');
const phone = ref('');

// Watch for token changes and redirect if logged out
watch(() => authStore.token, (token) => {
  if (!token) router.push('/login');
});

onMounted(() => {
  if (!authStore.token) {
    router.push('/login');
    return;
  }
  contactsStore.fetchContacts();
});

const addContact = async () => {
  // Basic frontend validation
  if (!name.value.trim() || !email.value.trim() || !phone.value.trim()) {
    alert('All fields are required.');
    return;
  }
  // Simple email format check
  const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  if (!emailPattern.test(email.value)) {
    alert('Please enter a valid email address.');
    return;
  }
  // Simple phone number check (10-15 digits)
  const phonePattern = /^\d{10,15}$/;
  if (!phonePattern.test(phone.value.replace(/\D/g, ''))) {
    alert('Please enter a valid phone number (10-15 digits).');
    return;
  }
  try {
    await contactsStore.addContact({ name: name.value, email: email.value, phone: phone.value });
    showAdd.value = false;
    name.value = email.value = phone.value = '';
  } catch (err) {
    alert(contactsStore.error || 'Failed to add contact.');
  }
};

const deleteContact = async (id) => {
  if (confirm('Are you sure you want to delete this contact?')) {
    try {
      await contactsStore.deleteContact(id);
    } catch (err) {
      alert(contactsStore.error || 'Failed to delete contact.');
    }
  }
};
</script>
