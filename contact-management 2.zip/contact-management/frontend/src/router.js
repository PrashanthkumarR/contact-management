import { createRouter, createWebHistory } from 'vue-router';
import Login from './views/Login.vue';
import Register from './views/Register.vue';
import Contacts from './views/Contacts.vue';
import ContactDetail from './views/ContactDetail.vue';

const routes = [
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  { path: '/', component: Contacts },
  { path: '/contacts/:id', component: ContactDetail, props: true },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
