import { defineStore } from 'pinia';
import api from '../api';

export const useContactsStore = defineStore('contacts', {
  state: () => ({
    contacts: [],
    loading: false,
    error: null,
  }),
  actions: {
    async fetchContacts() {
      this.loading = true;
      try {
        const res = await api.get('/contacts');
        this.contacts = res.data;
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to fetch contacts';
      } finally {
        this.loading = false;
      }
    },
    async addContact(contact) {
      try {
        const res = await api.post('/contacts', contact);
        this.contacts.push(res.data);
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to add contact';
      }
    },
    async updateContact(id, updates) {
      try {
        const res = await api.put(`/contacts/${id}`, updates);
        const idx = this.contacts.findIndex(c => c._id === id);
        if (idx !== -1) this.contacts[idx] = res.data;
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to update contact';
      }
    },
    async deleteContact(id) {
      try {
        await api.delete(`/contacts/${id}`);
        this.contacts = this.contacts.filter(c => c._id !== id);
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to delete contact';
      }
    },
  },
});
