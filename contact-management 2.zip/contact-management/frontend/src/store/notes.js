import { defineStore } from 'pinia';
import api from '../api';

export const useNotesStore = defineStore('notes', {
  state: () => ({
    notes: [],
    loading: false,
    error: null,
  }),
  actions: {
    async fetchNotes(contactId) {
      this.loading = true;
      try {
        const res = await api.get(`/contacts/${contactId}/notes`);
        this.notes = res.data;
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to fetch notes';
      } finally {
        this.loading = false;
      }
    },
    async addNote(contactId, content) {
      try {
        const res = await api.post(`/contacts/${contactId}/notes`, { content });
        this.notes.push(res.data);
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to add note';
      }
    },
    async updateNote(contactId, noteId, updates) {
      try {
        const res = await api.put(`/contacts/${contactId}/notes/${noteId}`, updates);
        const idx = this.notes.findIndex(n => n._id === noteId);
        if (idx !== -1) this.notes[idx] = res.data;
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to update note';
      }
    },
    async deleteNote(contactId, noteId) {
      try {
        await api.delete(`/contacts/${contactId}/notes/${noteId}`);
        this.notes = this.notes.filter(n => n._id !== noteId);
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to delete note';
      }
    },
  },
});
