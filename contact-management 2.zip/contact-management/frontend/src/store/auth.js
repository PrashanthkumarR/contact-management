import { defineStore } from 'pinia';
import api from '../api';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('token') || '',
    user: null,
    loading: false,
    error: null,
  }),
  actions: {
    async login(username, password) {
      this.loading = true;
      this.error = null;
      try {
        const res = await api.post('/auth/login', { username, password });
        this.token = res.data.token;
        localStorage.setItem('token', this.token);
        // Optionally fetch user info here
      } catch (err) {
        this.error = err.response?.data?.message || 'Login failed';
      } finally {
        this.loading = false;
      }
    },
    async register(username, password, organizationName) {
      this.loading = true;
      this.error = null;
      try {
        const res = await api.post('/auth/register', { username, password, organizationName });
        this.token = res.data.token;
        localStorage.setItem('token', this.token);
      } catch (err) {
        this.error = err.response?.data?.message || 'Registration failed';
      } finally {
        this.loading = false;
      }
    },
    logout() {
      this.token = '';
      this.user = null;
      localStorage.removeItem('token');
    },
  },
});
