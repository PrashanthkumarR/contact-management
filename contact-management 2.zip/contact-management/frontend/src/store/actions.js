import { defineStore } from 'pinia';
import api from '../api';

export const useActionsStore = defineStore('actions', {
  state: () => ({
    actions: [],
    loading: false,
    error: null,
  }),
  actions: {
    async fetchActions(contactId) {
      this.loading = true;
      try {
        const res = await api.get(`/contacts/${contactId}/actions`);
        this.actions = res.data;
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to fetch actions';
      } finally {
        this.loading = false;
      }
    },
    async addAction(contactId, action) {
      try {
        const res = await api.post(`/contacts/${contactId}/actions`, action);
        this.actions.push(res.data);
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to add action';
      }
    },
    async updateAction(contactId, actionId, updates) {
      try {
        const res = await api.put(`/contacts/${contactId}/actions/${actionId}`, updates);
        const idx = this.actions.findIndex(a => a._id === actionId);
        if (idx !== -1) this.actions[idx] = res.data;
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to update action';
      }
    },
    async deleteAction(contactId, actionId) {
      try {
        await api.delete(`/contacts/${contactId}/actions/${actionId}`);
        this.actions = this.actions.filter(a => a._id !== actionId);
      } catch (err) {
        this.error = err.response?.data?.message || 'Failed to delete action';
      }
    },
  },
});
