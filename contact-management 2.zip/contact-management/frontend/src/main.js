import { createApp } from 'vue';
import { createPinia } from 'pinia';
import router from './router';
import './style.css';
import './index.css';
import App from './App.vue';
import ContactCard from './components/ContactCard.vue';
import ContactForm from './components/ContactForm.vue';

const app = createApp(App);
app.use(createPinia());
app.use(router);
app.component('ContactCard', ContactCard);
app.component('ContactForm', ContactForm);
app.mount('#app');
