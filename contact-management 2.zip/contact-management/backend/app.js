
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');


const app = express();

// Security: Helmet for HTTP headers
app.use(helmet());

// Security: Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Security: CORS - restrict origins in production
const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3000').split(',');
app.use(cors({
  origin: function (origin, callback) {
    // allow requests with no origin (like mobile apps, curl, etc.)
    if (!origin) return callback(null, true);
    if (allowedOrigins.indexOf(origin) === -1) {
      return callback(new Error('CORS policy: This origin is not allowed.'), false);
    }
    return callback(null, true);
  },
  credentials: true,
}));

app.use(express.json());

const authRouter = require('./src/routes/auth');
app.use('/api/auth', authRouter);

const contactsRouter = require('./src/routes/contacts');
app.use('/api/contacts', contactsRouter);

const notesRouter = require('./src/routes/notes');
app.use('/api/contacts/:contactId/notes', notesRouter);

const actionsRouter = require('./src/routes/actions');
app.use('/api/contacts/:contactId/actions', actionsRouter);

module.exports = app;
