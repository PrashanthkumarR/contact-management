const express = require('express');
const auth = require('../middlewares/auth');
const actionController = require('../controllers/actionController');

const router = express.Router({ mergeParams: true });

// Get all action logs for a contact
router.get('/', auth, actionController.getAll);

// Add an action log to a contact
router.post('/', auth, actionController.create);

// Update an action log
router.put('/:actionId', auth, actionController.update);

// Delete an action log
router.delete('/:actionId', auth, actionController.remove);

module.exports = router;
