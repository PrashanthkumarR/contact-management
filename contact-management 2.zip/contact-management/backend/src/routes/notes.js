const express = require('express');
const auth = require('../middlewares/auth');
const noteController = require('../controllers/noteController');

const router = express.Router({ mergeParams: true });

// Get all notes for a contact
router.get('/', auth, noteController.getAll);

// Add a note to a contact
router.post('/', auth, noteController.create);

// Update a note
router.put('/:noteId', auth, noteController.update);

// Delete a note
router.delete('/:noteId', auth, noteController.remove);

module.exports = router;
