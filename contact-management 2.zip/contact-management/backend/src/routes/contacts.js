const express = require('express');
const auth = require('../middlewares/auth');
const contactController = require('../controllers/contactController');

const router = express.Router();

// Get all contacts for the user's organization
router.get('/', auth, contactController.getAll);

// Create a new contact
router.post('/', auth, contactController.create);

// Update a contact
router.put('/:id', auth, contactController.update);

// Delete a contact
router.delete('/:id', auth, contactController.remove);

module.exports = router;
