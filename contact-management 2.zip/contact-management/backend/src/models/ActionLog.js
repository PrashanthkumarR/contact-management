const mongoose = require('mongoose');

const actionLogSchema = new mongoose.Schema({
  contactId: { type: mongoose.Schema.Types.ObjectId, ref: 'Contact', required: true },
  actionType: { type: String, enum: ['email', 'call', 'in-person'], required: true },
  date: { type: Date, required: true },
  notes: { type: String },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
}, { timestamps: true });

module.exports = mongoose.model('ActionLog', actionLogSchema);
