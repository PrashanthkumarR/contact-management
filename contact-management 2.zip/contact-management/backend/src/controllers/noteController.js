const logger = require('../config/loggerService');
const Note = require('../models/Note');

exports.getAll = async (req, res) => {
  logger.info(`User ${req.user._id} fetching notes for contact ${req.params.contactId}`);
  const notes = await Note.find({ contactId: req.params.contactId });
  res.json(notes);
};

exports.create = async (req, res) => {
  const note = new Note({
    contactId: req.params.contactId,
    content: req.body.content,
    createdBy: req.user._id,
  });
  await note.save();
  logger.info(`User ${req.user._id} created note for contact ${req.params.contactId}`);
  res.status(201).json(note);
};

exports.update = async (req, res) => {
  const note = await Note.findOneAndUpdate(
    { _id: req.params.noteId, contactId: req.params.contactId },
    req.body,
    { new: true },
  );
  if (!note) {
    logger.warn(`User ${req.user._id} tried to update non-existent note ${req.params.noteId}`);
    return res.status(404).json({ message: 'Note not found' });
  }
  logger.info(`User ${req.user._id} updated note ${req.params.noteId}`);
  res.json(note);
};

exports.remove = async (req, res) => {
  const note = await Note.findOneAndDelete({ _id: req.params.noteId, contactId: req.params.contactId });
  if (!note) {
    logger.warn(`User ${req.user._id} tried to delete non-existent note ${req.params.noteId}`);
    return res.status(404).json({ message: 'Note not found' });
  }
  logger.info(`User ${req.user._id} deleted note ${req.params.noteId}`);
  res.json({ message: 'Note deleted' });
};
