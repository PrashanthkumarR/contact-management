const logger = require('../config/loggerService');
const User = require('../models/User');
const Organization = require('../models/Organization');
const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/env');

exports.register = async (req, res) => {
  try {
    const { username, password, organizationName } = req.body;
    let organization = await Organization.findOne({ name: organizationName });
    if (!organization) {
      organization = await Organization.create({ name: organizationName });
      logger.info(`New organization created: ${organizationName}`);
    }
    const user = new User({ username, password, organizationId: organization._id, role: 'admin' });
    await user.save();
    logger.info(`User registered: ${username} (org: ${organizationName})`);
    const token = jwt.sign({ id: user._id, organizationId: organization._id }, jwtSecret, { expiresIn: '7d' });
    res.status(201).json({ token });
  } catch (err) {
    logger.error(`Registration failed for ${req.body.username}: ${err.message}`);
    res.status(400).json({ message: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) {
      logger.warn(`Login failed: user not found (${username})`);
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      logger.warn(`Login failed: wrong password (${username})`);
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    logger.info(`User logged in: ${username}`);
    const token = jwt.sign({ id: user._id, organizationId: user.organizationId }, jwtSecret, { expiresIn: '7d' });
    res.json({ token });
  } catch (err) {
    logger.error(`Login error for ${req.body.username}: ${err.message}`);
    res.status(400).json({ message: err.message });
  }
};
