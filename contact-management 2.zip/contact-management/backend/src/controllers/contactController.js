const logger = require('../config/loggerService');
const Contact = require('../models/Contact');

exports.getAll = async (req, res) => {
  logger.info(`User ${req.user._id} fetching contacts for org ${req.organizationId}`);
  const contacts = await Contact.find({ organizationId: req.organizationId });
  res.json(contacts);
};

exports.create = async (req, res) => {
  const { name, phone, email } = req.body;
  const contact = new Contact({
    name,
    phone,
    email,
    organizationId: req.organizationId,
    createdBy: req.user._id,
  });
  await contact.save();
  logger.info(`User ${req.user._id} created contact ${contact._id}`);
  res.status(201).json(contact);
};

exports.update = async (req, res) => {
  const contact = await Contact.findOneAndUpdate(
    { _id: req.params.id, organizationId: req.organizationId },
    req.body,
    { new: true },
  );
  if (!contact) {
    logger.warn(`User ${req.user._id} tried to update non-existent contact ${req.params.id}`);
    return res.status(404).json({ message: 'Contact not found' });
  }
  logger.info(`User ${req.user._id} updated contact ${req.params.id}`);
  res.json(contact);
};

exports.remove = async (req, res) => {
  const contact = await Contact.findOneAndDelete({ _id: req.params.id, organizationId: req.organizationId });
  if (!contact) {
    logger.warn(`User ${req.user._id} tried to delete non-existent contact ${req.params.id}`);
    return res.status(404).json({ message: 'Contact not found' });
  }
  logger.info(`User ${req.user._id} deleted contact ${req.params.id}`);
  res.json({ message: 'Contact deleted' });
};
