const logger = require('../config/loggerService');
const ActionLog = require('../models/ActionLog');

exports.getAll = async (req, res) => {
  logger.info(`User ${req.user._id} fetching actions for contact ${req.params.contactId}`);
  const actions = await ActionLog.find({ contactId: req.params.contactId });
  res.json(actions);
};

exports.create = async (req, res) => {
  const { actionType, date, notes } = req.body;
  const action = new ActionLog({
    contactId: req.params.contactId,
    actionType,
    date,
    notes,
    createdBy: req.user._id,
  });
  await action.save();
  logger.info(`User ${req.user._id} created action for contact ${req.params.contactId}`);
  res.status(201).json(action);
};

exports.update = async (req, res) => {
  const action = await ActionLog.findOneAndUpdate(
    { _id: req.params.actionId, contactId: req.params.contactId },
    req.body,
    { new: true },
  );
  if (!action) {
    logger.warn(`User ${req.user._id} tried to update non-existent action ${req.params.actionId}`);
    return res.status(404).json({ message: 'Action log not found' });
  }
  logger.info(`User ${req.user._id} updated action ${req.params.actionId}`);
  res.json(action);
};

exports.remove = async (req, res) => {
  const action = await ActionLog.findOneAndDelete({ _id: req.params.actionId, contactId: req.params.contactId });
  if (!action) {
    logger.warn(`User ${req.user._id} tried to delete non-existent action ${req.params.actionId}`);
    return res.status(404).json({ message: 'Action log not found' });
  }
  logger.info(`User ${req.user._id} deleted action ${req.params.actionId}`);
  res.json({ message: 'Action log deleted' });
};
